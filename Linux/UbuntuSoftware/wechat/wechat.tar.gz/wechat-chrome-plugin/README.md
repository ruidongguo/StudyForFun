谷歌微信插件
================
> 谷歌拓展程序

##安装
```bash
  git clone https://github.com/jarden-liu/wechat-chrome-plugin.git
```
* 打开谷歌浏览器，进入[chrome://extensions/](chrome://extensions/)，开启`开发者模式`,`加载已解压的拓展程序`，找到wechat-chrome-plugin文件夹导入。
* 进入[chrome://settings/content](chrome://settings/content),设置通知为允许所有网站显示通知，或者将`https://wx.qq/com/*`添加到例外情况。
